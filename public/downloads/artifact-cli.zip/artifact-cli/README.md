# Artifact CLI

The canonical TUI (Terminal User Interface) for the Yukora archival system.

## What is Artifact CLI?

Artifact CLI is a Rich-based Python terminal application that provides a user-friendly interface for:
- **Scanning & Archiving**: Import photos, videos, documents, and other artifacts from your filesystem
- **Tree Management**: Create and manage family members/entities in the archive tree
- **Metadata**: Add descriptions, locations, and categorizations to artifacts
- **Firebase Integration**: Upload artifacts directly to Firestore with full metadata preservation

## Installation

\\\ash
pip install -r requirements.txt
python main.py
\\\

## Usage

Launch the TUI and follow the menu-driven interface to:
1. Add new family members to the tree
2. Scan folders for artifacts
3. Tag artifacts with metadata
4. Upload to Firebase

## Architecture

- **main.py**: Rich menu system (entry point)
- **firebase_service.py**: Firebase Admin SDK wrapper
- **tree_menu.py**: Member CRUD operations
- **archive_menu.py**: File picker & artifact upload

## License

Private/Proprietary

