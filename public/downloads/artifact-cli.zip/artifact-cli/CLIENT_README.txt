SCHNITZELBANK ARTIFACT CLI - QUICK START
========================================

1. Unzip this folder to your computer.
2. Double-click "Launch Artifact CLI.bat" to start.

NOTE FOR WINDOWS USERS:
If you see a "Windows protected your PC" popup:
1. Click "More info"
2. Click "Run anyway"

This warning appears because the script is not digitally signed, but it is safe to run as part of your Schnitzelbank archive tools.
