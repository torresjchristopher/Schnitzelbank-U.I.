#!/usr/bin/env python3
"""
Create ZIP release of Schnitzel Bank Artifacts
Password protection handled by 7-Zip or WinRAR after creation
"""

import zipfile
import os
from pathlib import Path

def create_release(source_dir, output_file):
    """Create ZIP file of the TUI application."""
    
    source_path = Path(source_dir)
    
    # Files/folders to exclude
    exclude_dirs = {
        '__pycache__',
        '.git',
        '.pytest_cache',
        'venv',  # Don't include venv - user will set it up
    }
    
    exclude_files = {
        '.gitignore',
        'test_archive.py',
        'create_release.py',
        'firebase-service-account.json',
        '.env',
        '.env.local',
        '*.pyc',
        '*.pyo'
    }
    
    print("=" * 70)
    print("CREATING ARTIFACTS RELEASE PACKAGE")
    print("=" * 70)
    print()
    
    if os.path.exists(output_file):
        os.remove(output_file)
        print(f"Removed existing: {output_file}")
    
    total_files = 0
    total_size = 0
    
    with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_path):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                # Skip excluded files
                if any(file.endswith(ext) for ext in ['.pyc', '.pyo']):
                    continue
                if file in exclude_files:
                    continue
                
                file_path = Path(root) / file
                arcname = file_path.relative_to(source_path.parent)
                
                try:
                    zipf.write(file_path, arcname)
                    total_files += 1
                    total_size += os.path.getsize(file_path)
                    print(f"  ✓ {arcname}")
                except Exception as e:
                    print(f"  ✗ {arcname} (error: {e})")
    
    size_mb = total_size / 1024 / 1024
    
    print()
    print("=" * 70)
    print("PACKAGE CREATED SUCCESSFULLY!")
    print("=" * 70)
    print()
    print(f"  Location: {output_file}")
    print(f"  Files: {total_files}")
    print(f"  Size: {size_mb:.2f} MB")
    print()
    print("NEXT STEP - ADD PASSWORD PROTECTION:")
    print()
    print("  1. Download and install 7-Zip (free):")
    print("     https://www.7-zip.org/download.html")
    print()
    print("  2. Right-click the ZIP file")
    print("  3. Select: 7-Zip → Add to archive...")
    print()
    print("  4. In the dialog:")
    print("     - Archive format: 7z (for better compression)")
    print("     - Enter password: JACKSON_HEIGHTS")
    print("     - Repeat password")
    print()
    print("  5. Click OK - this creates artifacts-release.7z")
    print()
    print("THEN UPLOAD TO GITHUB PAGES with instructions:")
    print("  - File: artifacts-release.7z")
    print("  - Password: JACKSON_HEIGHTS")
    print()

if __name__ == "__main__":
    source = r"C:\Users\serro\yukora\schnitzel-tui"
    output = r"C:\Users\serro\Downloads\artifacts-release.zip"
    
    create_release(source, output)
