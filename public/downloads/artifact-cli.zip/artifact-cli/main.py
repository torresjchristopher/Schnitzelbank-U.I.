#!/usr/bin/env python3
"""
Schnitzel Bank TUI - Terminal UI for family heritage archive management
Arrow key navigation with real-time display using Rich Live
"""

import os
import sys
import webbrowser
import msvcrt
from typing import List
from pathlib import Path

from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from rich.table import Table
from rich import box

from firebase_service import FirebaseService
from archive_menu import ArchiveMenu
from tree_menu import TreeMenu
from delete_menu import DeleteMenu


class SchnitzelTUI:
    def __init__(self):
        self.console = Console()
        self.firebase = FirebaseService()
        self.archive_menu = ArchiveMenu(self.firebase, self.console)
        self.tree_menu = TreeMenu(self.firebase, self.console)
        self.delete_menu = DeleteMenu(self.firebase, self.console)
        
        self.menu_options = [
            "Add Artifact",
            "Edit Tree",
            "Delete Artifact",
            "Gallery",
            "Exit",
        ]
        self.menu_descriptions = [
            "Ingest new high-resolution artifacts into the archive",
            "Manage family subjects and cryptographic lineages",
            "Search and permanently delete artifacts from the vault",
            "Launch the immersive gallery at schnitzelbank.org",
            "Safely terminate the Artifact CLI session",
        ]
        self.current_index = 0
        self.running = True
    
    def draw_menu(self):
        """Draw main menu with arrow navigation."""
        table = Table(box=box.ROUNDED, show_header=False, expand=True, border_style="white")
        
        for i, (option, desc) in enumerate(zip(self.menu_options, self.menu_descriptions)):
            style = "bold white on grey15" if i == self.current_index else "white"
            prefix = "→ " if i == self.current_index else "  "
            table.add_row(
                Text(f"{prefix}{option}", style=style),
                Text(desc, style="dim")
            )
        
        return Panel(
            table,
            title="[bold]SCHNITZEL BANK[/bold]",
            subtitle="[dim]Arrows: Navigate | Enter: Select | Esc: Exit[/dim]",
            border_style="white"
        )
    
    def show_main_menu(self):
        """Main menu loop with arrow key navigation."""
        with Live(refresh_per_second=10, screen=True) as live:
            while self.running:
                live.update(self.draw_menu())
                
                if msvcrt.kbhit():
                    key = ord(msvcrt.getch())
                    
                    # Arrow keys (Windows: first byte is 224, second is direction)
                    if key == 224:
                        direction = ord(msvcrt.getch())
                        if direction == 72:  # Up
                            self.current_index = (self.current_index - 1) % len(self.menu_options)
                        elif direction == 80:  # Down
                            self.current_index = (self.current_index + 1) % len(self.menu_options)
                    
                    # Enter key
                    elif key == 13:
                        if self.current_index == 0: # Add Artifact
                            live.stop()
                            self.archive_menu.show()
                            live.start()
                        elif self.current_index == 1: # Edit Tree
                            live.stop()
                            self.tree_menu.show()
                            live.start()
                        elif self.current_index == 2: # Purge Artifact
                            live.stop()
                            self.delete_menu.show()
                            live.start()
                        elif self.current_index == 3: # Gallery
                            live.stop()
                            self.open_view_bank()
                            live.start()
                        elif self.current_index == 4: # Exit
                            self.running = False
                    
                    # Esc to quit
                    elif key == 27:
                        self.running = False
    
    def open_view_bank(self):
        """Open the website in browser."""
        self.console.print("\nOpening View Bank...")
        webbrowser.open("https://schnitzelbank.org")
        Prompt.ask("Press Enter when done")


def main():
    """Entry point for the TUI application."""
    try:
        app = SchnitzelTUI()
        app.show_main_menu()
        app.console.print("\nGoodbye.")
    except KeyboardInterrupt:
        print("\n\nAborted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\nError: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
