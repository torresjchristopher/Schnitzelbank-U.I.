"""
Cross-platform file picker using tkinter or native dialogs
"""

import sys
from pathlib import Path
from typing import List


class FilePicker:
    """File picker that works on Windows, Mac, and Linux."""
    
    def __init__(self):
        self.supported_formats = {
            '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp',  # Images
            '.mp4', '.mov', '.avi', '.mkv', '.webm', '.flv',    # Videos
            '.pdf', '.doc', '.docx', '.txt', '.ppt', '.pptx',   # Documents
            '.xls', '.xlsx', '.csv',                             # Spreadsheets
            '.zip', '.rar', '.7z',                               # Archives
        }
    
    def pick_files(self) -> List[Path]:
        """Open file picker dialog and return selected file paths."""
        try:
            import tkinter as tk
            from tkinter import filedialog
            
            root = tk.Tk()
            root.withdraw()  # Hide the main window
            
            # Open file dialog with multi-select
            files = filedialog.askopenfilenames(
                title="Select artifacts to archive",
                filetypes=[
                    ("All Supported", ";".join(f"*{ext}" for ext in self.supported_formats)),
                    ("Images", "*.jpg *.jpeg *.png *.gif *.bmp *.webp"),
                    ("Videos", "*.mp4 *.mov *.avi *.mkv *.webm"),
                    ("Documents", "*.pdf *.doc *.docx *.txt"),
                    ("All Files", "*.*")
                ]
            )
            
            root.destroy()
            
            return [Path(f) for f in files] if files else []
        
        except Exception as e:
            print(f"File picker error: {e}")
            return []
    
    def pick_folder(self) -> Path:
        """Open folder picker dialog."""
        try:
            import tkinter as tk
            from tkinter import filedialog
            
            root = tk.Tk()
            root.withdraw()
            
            folder = filedialog.askdirectory(title="Select folder")
            root.destroy()
            
            return Path(folder) if folder else None
        
        except Exception as e:
            print(f"Folder picker error: {e}")
            return None
