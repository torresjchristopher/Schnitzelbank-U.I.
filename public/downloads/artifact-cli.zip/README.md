# Schnitzel Bank TUI

Terminal UI for managing family heritage archives. Built with Python + Rich + Firebase.

## Installation

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Running

```bash
python main.py
```

## Features

- **Archive**: Add new artifacts with batch file selection and metadata collection
- **Manage Tree**: Add, edit, delete family members
- **View Bank**: Open the web gallery (schnitzelbank.org)

## Architecture

```
schnitzel-tui/
├── main.py                  # Main entry point
├── firebase_service.py      # Firebase Admin SDK wrapper
├── archive_menu.py          # File picker + artifact metadata
├── tree_menu.py             # Family member management
├── file_picker.py           # Cross-platform file picker (tkinter)
└── requirements.txt         # Python dependencies
```

## Firebase Setup

For full functionality, place a Firebase service account JSON file at:
```
~/.schnitzel/firebase-service-account.json
```

Get this from Firebase Console → Project Settings → Service Accounts → Generate private key
