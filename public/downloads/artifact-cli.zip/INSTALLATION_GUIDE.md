# Schnitzel Bank Artifacts - Installation Guide

## 📦 What's Included

This is the **Artifacts** application - a Terminal User Interface (TUI) for the Schnitzel Bank family heritage archive system.

### Features
- **Archive**: Add photos, videos, and documents to the family archive
- **Manage Tree**: Add, edit, or delete family members
- **View Bank**: Open the online gallery in your web browser

## 🚀 Installation

### Step 1: Extract the ZIP
Right-click `artifacts-release.zip` and select **Extract All**

Windows will extract to a folder. Choose any location, e.g.:
```
C:\Users\[YourUsername]\Artifacts
```

### Step 2: Install Python (First Time Only)
If you don't have Python installed:

1. Visit: https://www.python.org/downloads/
2. Download **Python 3.11 or later**
3. Run the installer
4. **IMPORTANT**: Check "Add Python to PATH"
5. Click "Install Now"

**Verify installation:**
```
Open Command Prompt and type:
python --version
```

### Step 3: Install Dependencies (First Time Only)
1. Open Command Prompt **in the extracted folder**
2. Run:
   ```
   venv\Scripts\python.exe -m pip install -r requirements.txt
   ```

This only needs to happen once!

### Step 4: Run the Application
**Double-click `launch.bat`**

Or in Command Prompt:
```
venv\Scripts\python.exe main.py
```

That's it! 🎉

## 📋 First Time Setup

### Firebase Configuration
The application connects to the Schnitzel Bank Firebase database. Credentials should be automatically configured.

If you see a warning about missing credentials:
1. Contact the administrator
2. Place `firebase-service-account.json` in: `C:\Users\[YourUsername]\.schnitzel\`

## 🎯 How to Use

### Adding Family Members
1. Select **"2. Manage Tree"** from main menu
2. Choose **"2. Add Member"**
3. Enter: Name, Birth Date (optional), Bio (optional)
4. Member is saved to database

### Adding Artifacts
1. Select **"1. Archive"** from main menu
2. Choose **"1. Select Files"**
3. Select one or more files (photos, videos, documents)
4. For each file:
   - Select family member it belongs to
   - Add description (optional)
   - Add tags (optional)
5. Review summary and upload
6. Done! Artifacts are saved

### Viewing Online Gallery
1. Select **"3. View Bank"** from main menu
2. Browser opens to schnitzelbank.org
3. View all family photos, videos, and documents
4. Download ZIP or Memory Book PDF

## ❓ Troubleshooting

**"Firebase service account not found"**
- Contact administrator for credentials file
- Place in: `C:\Users\[YourUsername]\.schnitzel\`

**"Python not found"**
- Reinstall Python and check "Add Python to PATH"
- Restart Command Prompt after installation

**File picker doesn't open**
- Tkinter (file picker) requires Python to be installed with tkinter support
- Reinstall Python and select "tcl/tk and IDLE"

## 📞 Support

For issues or questions about:
- Artifacts app → Contact: [Administrator]
- Website gallery → Visit: https://schnitzelbank.org
- Family records → Contact: [Family Administrator]

---

**Schnitzel Bank - Preserving Family Heritage**

Version 1.0.0
Released: February 2026
