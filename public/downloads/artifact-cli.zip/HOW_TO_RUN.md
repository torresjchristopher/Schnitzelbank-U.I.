# Running the Schnitzel Bank TUI

## Quick Start

### Option 1: Direct Command (Easiest)
```bash
cd C:\Users\serro\yukora\schnitzel-tui
.\venv\Scripts\python.exe main.py
```

### Option 2: Create Windows Shortcut
1. Right-click on Desktop → **New → Shortcut**
2. Enter this location:
   ```
   C:\Users\serro\yukora\schnitzel-tui\venv\Scripts\python.exe main.py
   ```
3. Name it: **Schnitzel Bank Artifacts**
4. Click Finish
5. Double-click to launch!

### Option 3: Use Batch File (For Downloaded Version)
If you downloaded the `artifacts-release.zip`:
1. Extract the ZIP with Windows native extractor (right-click → Extract All)
2. Navigate to the extracted folder
3. Double-click `launch.bat`

That's it!

## What You'll See

Menu with 4 options:
```
🏛️ SCHNITZEL BANK
   Family Heritage Archive

Main Menu
1. 📦 Archive - Add new artifacts
2. 👨‍👩‍👧‍👦 Manage Tree - Edit family members
3. 📚 View Bank - Open website gallery
4. ❌ Quit
```

## Requirements

- Python 3.11+ installed
- Firebase credentials at: `C:\Users\serro\.schnitzel\firebase-service-account.json`
- Internet connection

That's it! The TUI is ready to use. 🎉
